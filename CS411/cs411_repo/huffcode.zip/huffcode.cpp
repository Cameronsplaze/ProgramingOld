// huffcode.cpp  UNFINISHED
// Glenn G. Chappell
// 29 Nov 2015
//
// For CS 411/611 Fall 2015
// Assignment 6, Exercise A
// Source for class HuffCode

#include "huffcode.h"  // for class HuffCode declaration
#include <string>
using std::string;
#include <unordered_map>
using std::unordered_map;


void HuffCode::setWeights(const unordered_map<char, int> & theweights)
{
    // WRITE THIS!!!
}


string HuffCode::encode(const string & text) const
{
    // WRITE THIS!!!
    return "";  // DUMMY RETURN
}


string HuffCode::decode(const string & codestr) const
{
    // WRITE THIS!!!
    return "";  // DUMMY RETURN
}

