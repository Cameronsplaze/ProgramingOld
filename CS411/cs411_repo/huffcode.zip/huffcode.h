// huffcode.h  UNFINISHED
// Glenn G. Chappell
// 29 Nov 2015
//
// For CS 411/611 Fall 2015
// Assignment 6, Exercise A
// Header for class HuffCode

#ifndef FILE_HUFFCODE_H_INCLUDED
#define FILE_HUFFCODE_H_INCLUDED

#include <string>
using std::string;
#include <unordered_map>
using std::unordered_map;


// Class HuffCode
// Encoding & decoding using a Huffman code
class HuffCode {

// ***** HuffCode: ctors, dctor, op= *****
public:

    // Compiler-generated default ctor, copy ctor, copy =, dctor used

// ***** HuffCode: general public functions *****
public:

    void setWeights(const unordered_map<char, int> & theweights);

    string encode(const string & text) const;

    string decode(const string & codestr) const;

// ***** HuffCode: data members *****
private:

};  // End class HuffCode


#endif //#ifndef FILE_HUFFCODE_H_INCLUDED

